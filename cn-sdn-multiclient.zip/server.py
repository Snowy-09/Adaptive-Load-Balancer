import socket
import sys
import time
import json
import threading
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from concurrent.futures import ThreadPoolExecutor


CONFIG_FILE = Path(__file__).resolve().parent / "dashboard" / "config.json"
DEFAULT_DELAY_SECONDS = 0.1


def get_processing_delay():
    """Read this backend's delay from the dashboard configuration."""
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as config_file:
            config = json.load(config_file)

        delays = config.get("delays_ms", {})
        delay_ms = float(delays.get(NAME, DEFAULT_DELAY_SECONDS * 1000))

        # Keep delay values within the supported 0–5000 ms range.
        delay_ms = max(0.0, min(5000.0, delay_ms))
        return delay_ms / 1000.0
    except (OSError, ValueError, TypeError, AttributeError):
        return DEFAULT_DELAY_SECONDS


PORT = int(sys.argv[1])
NAME = sys.argv[2]
METRICS_PORT = PORT + 1000

MAX_WORKERS = 50
lock = threading.Lock()

# Process CPU accounting. Normalized to the available CPU cores.
_last_cpu_time = time.process_time()
_last_wall_time = time.monotonic()
cpu_utilization_percent = 0.0
cpu_lock = threading.Lock()

def update_cpu_usage():
    global _last_cpu_time, _last_wall_time, cpu_utilization_percent

    now_cpu = time.process_time()
    now_wall = time.monotonic()

    cpu_delta = now_cpu - _last_cpu_time
    wall_delta = now_wall - _last_wall_time

    if wall_delta > 0:
        # 100% means one full CPU core; normalize for VM core count.
        cores = os.cpu_count() or 1
        usage = (cpu_delta / wall_delta) * 100.0 / cores
        cpu_utilization_percent = max(0.0, min(100.0, usage))

    _last_cpu_time = now_cpu
    _last_wall_time = now_wall

def get_cpu_usage():
    with cpu_lock:
        update_cpu_usage()
        return round(cpu_utilization_percent, 2)

stats = {
    "server": NAME,
    "tcp_port": PORT,
    "metrics_port": METRICS_PORT,
    "total_connections": 0,
    "total_requests": 0,
    "active_connections": 0,
    "successful_requests": 0,
    "failed_requests": 0,
    "total_processing_seconds": 0.0,
    "last_request_time": None,
}

def handle_client(conn, addr):
    with lock:
        stats["total_connections"] += 1
        stats["active_connections"] += 1

    start = time.perf_counter()
    success = False
    valid_request = False

    try:
        with conn:
            conn.settimeout(10)
            request = conn.recv(4096).decode().strip()

            if not request:
                return

            valid_request = True

            with lock:
                stats["total_requests"] += 1
                stats["last_request_time"] = time.time()

            print(f"{NAME} received {request} from {addr}", flush=True)

            # Simulated application processing.
            time.sleep(get_processing_delay())

            conn.sendall(f"Handled by {NAME}: {request}\n".encode())
            success = True

    except (ConnectionError, OSError, socket.timeout) as exc:
        print(f"{NAME} connection error: {exc}", flush=True)

    finally:
        elapsed = time.perf_counter() - start

        with lock:
            stats["active_connections"] -= 1
            stats["total_processing_seconds"] += elapsed

            if success:
                stats["successful_requests"] += 1
            elif valid_request:
                stats["failed_requests"] += 1

def get_metrics():
    with lock:
        result = dict(stats)

    completed = result["successful_requests"] + result["failed_requests"]
    result["average_processing_ms"] = (
        result["total_processing_seconds"] / completed * 1000
        if completed else 0.0
    )

    result["cpu_utilization_percent"] = get_cpu_usage()
    result["healthy"] = True
    return result

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path not in ("/health", "/metrics"):
            self.send_error(404, "Not found")
            return

        body = json.dumps(get_metrics()).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass

def main():
    tcp_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_server.bind(("0.0.0.0", PORT))
    tcp_server.listen(100)

    metrics_server = ThreadingHTTPServer(
        ("0.0.0.0", METRICS_PORT), MetricsHandler
    )
    metrics_server.daemon_threads = True

    threading.Thread(
        target=metrics_server.serve_forever, daemon=True
    ).start()

    print(
        f"{NAME} TCP listening on {PORT}; metrics listening on {METRICS_PORT}",
        flush=True,
    )

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        try:
            while True:
                conn, addr = tcp_server.accept()
                pool.submit(handle_client, conn, addr)
        except KeyboardInterrupt:
            pass
        finally:
            tcp_server.close()
            metrics_server.shutdown()
            metrics_server.server_close()

if __name__ == "__main__":
    main()
