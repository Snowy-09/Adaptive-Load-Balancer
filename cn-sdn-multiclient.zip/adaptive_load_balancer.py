import json
import time

from os_ken.base import app_manager
from os_ken.controller import ofp_event
from os_ken.controller.handler import (
    CONFIG_DISPATCHER,
    MAIN_DISPATCHER,
    set_ev_cls,
)
from os_ken.ofproto import ofproto_v1_3
from os_ken.lib.packet import (
    packet, ethernet, arp, ipv4, tcp, ether_types
)

VIP = "10.0.0.100"
SERVICE_PORT = 5000
VIRTUAL_MAC = "02:00:00:00:00:64"
CLIENTS = {"10.0.0.1": 1, "10.0.0.2": 2, "10.0.0.3": 3}

HEALTH_FILE = "/tmp/cn_sdn_backend_health.json"
HEALTH_FILE_MAX_AGE = 8

BACKENDS = [
    {
        "ip": "10.0.0.4",
        "mac": None,
        "port": 4,
        "tcp_port": 5001,
        "name": "S1",
        "metrics_port": 6001,
    },
    {
        "ip": "10.0.0.5",
        "mac": None,
        "port": 5,
        "tcp_port": 5002,
        "name": "S2",
        "metrics_port": 6002,
    },
    {
        "ip": "10.0.0.6",
        "mac": None,
        "port": 6,
        "tcp_port": 5003,
        "name": "S3",
        "metrics_port": 6003,
    },
]


class LoadBalancer(app_manager.OSKenApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.mac_to_port = {}
        self.client_macs = {}
        self.next_backend = 0
        self.connections = {}
        self.assignment_counts = {
            backend["name"]: 0 for backend in BACKENDS
        }
        self.pending = {}
        self.arp_pending = set()

    def add_flow(
        self, dp, priority, match, actions, idle_timeout=60
    ):
        parser = dp.ofproto_parser
        ofproto = dp.ofproto

        instructions = [
            parser.OFPInstructionActions(
                ofproto.OFPIT_APPLY_ACTIONS, actions
            )
        ]

        dp.send_msg(parser.OFPFlowMod(
            datapath=dp,
            priority=priority,
            match=match,
            instructions=instructions,
            idle_timeout=idle_timeout,
        ))

    def send_packet(self, dp, in_port, actions, data):
        parser = dp.ofproto_parser
        ofproto = dp.ofproto

        dp.send_msg(parser.OFPPacketOut(
            datapath=dp,
            buffer_id=ofproto.OFP_NO_BUFFER,
            in_port=in_port,
            actions=actions,
            data=data,
        ))

    def packet_out(self, dp, msg, actions, data=None):
        self.send_packet(
            dp,
            msg.match["in_port"],
            actions,
            msg.data if data is None else data,
        )

    @set_ev_cls(
        ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER
    )
    def switch_ready(self, ev):
        dp = ev.msg.datapath
        parser = dp.ofproto_parser
        ofproto = dp.ofproto

        actions = [
            parser.OFPActionOutput(
                ofproto.OFPP_CONTROLLER,
                ofproto.OFPCML_NO_BUFFER,
            )
        ]

        self.add_flow(
            dp, 0, parser.OFPMatch(), actions,
            idle_timeout=0,
        )

        self.logger.info(
            "Load balancer connected to switch %s", dp.id
        )

    @set_ev_cls(
        ofp_event.EventOFPPacketIn, MAIN_DISPATCHER
    )
    def handle_packet(self, ev):
        msg = ev.msg
        dp = msg.datapath
        parser = dp.ofproto_parser
        ofproto = dp.ofproto
        in_port = msg.match["in_port"]

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)

        if eth is None:
            return

        self.mac_to_port.setdefault(dp.id, {})
        self.mac_to_port[dp.id][eth.src] = in_port


        for backend in BACKENDS:
            if in_port == backend["port"]:
                backend["mac"] = eth.src

        if eth.ethertype == ether_types.ETH_TYPE_ARP:
            self.handle_arp(dp, msg, pkt)
            return

        ip = pkt.get_protocol(ipv4.ipv4)
        tcp_header = pkt.get_protocol(tcp.tcp)

        if (
            ip is not None
            and tcp_header is not None
            and CLIENTS.get(ip.src) == in_port
            and ip.dst == VIP
            and tcp_header.dst_port == SERVICE_PORT
            and (tcp_header.bits & tcp.TCP_SYN) != 0
            and (tcp_header.bits & tcp.TCP_ACK) == 0
        ):
            self.handle_new_connection(
                dp, msg, ip, tcp_header, eth.src
            )
            return

        out_port = self.mac_to_port[dp.id].get(
            eth.dst, ofproto.OFPP_FLOOD
        )
        actions = [parser.OFPActionOutput(out_port)]

        if out_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(
                in_port=in_port,
                eth_dst=eth.dst,
            )
            self.add_flow(
                dp, 10, match, actions, idle_timeout=60
            )

        self.packet_out(dp, msg, actions)

    def handle_arp(self, dp, msg, pkt):
        parser = dp.ofproto_parser
        ofproto = dp.ofproto
        eth = pkt.get_protocol(ethernet.ethernet)
        arp_pkt = pkt.get_protocol(arp.arp)

        if eth is None or arp_pkt is None:
            return

        if arp_pkt.opcode == arp.ARP_REPLY:
            for backend in BACKENDS:
                if arp_pkt.src_ip == backend["ip"]:
                    backend["mac"] = arp_pkt.src_mac
                    self.logger.info(
                        "Learned %s MAC: %s",
                        backend["name"], backend["mac"]
                    )

                    waiting = [
                        key for key, item in self.pending.items()
                        if item["backend"] is backend
                    ]

                    for key in waiting:
                        item = self.pending.pop(key)
                        self.install_connection(
                            item["dp"],
                            item["in_port"],
                            item["data"],
                            item["client_ip"],
                            item["client_mac"],
                            item["client_port"],
                            backend,
                        )

                    self.arp_pending.discard(backend["ip"])

        if (
            arp_pkt.opcode == arp.ARP_REQUEST
            and arp_pkt.dst_ip == VIP
        ):
            reply = packet.Packet()
            reply.add_protocol(ethernet.ethernet(
                dst=eth.src,
                src=VIRTUAL_MAC,
                ethertype=ether_types.ETH_TYPE_ARP,
            ))
            reply.add_protocol(arp.arp(
                hwtype=1,
                proto=0x0800,
                hlen=6,
                plen=4,
                opcode=arp.ARP_REPLY,
                src_mac=VIRTUAL_MAC,
                src_ip=VIP,
                dst_mac=arp_pkt.src_mac,
                dst_ip=arp_pkt.src_ip,
            ))
            reply.serialize()

            self.packet_out(
                dp, msg,
                [parser.OFPActionOutput(ofproto.OFPP_IN_PORT)],
                reply.data,
            )
            self.logger.info("Answered ARP for %s", VIP)
            return

        self.packet_out(
            dp, msg,
            [parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
        )

    def request_backend_mac(self, dp, msg, backend):
        if backend["ip"] in self.arp_pending:
            return

        parser = dp.ofproto_parser

        request = packet.Packet()
        request.add_protocol(ethernet.ethernet(
            dst="ff:ff:ff:ff:ff:ff",
            src=VIRTUAL_MAC,
            ethertype=ether_types.ETH_TYPE_ARP,
        ))
        request.add_protocol(arp.arp(
            hwtype=1,
            proto=0x0800,
            hlen=6,
            plen=4,
            opcode=arp.ARP_REQUEST,
            src_mac=VIRTUAL_MAC,
            src_ip=VIP,
            dst_mac="00:00:00:00:00:00",
            dst_ip=backend["ip"],
        ))
        request.serialize()

        self.send_packet(
            dp,
            dp.ofproto.OFPP_CONTROLLER,
            [parser.OFPActionOutput(backend["port"])],
            request.data,
        )
        self.arp_pending.add(backend["ip"])

        self.logger.info(
            "Resolving MAC for %s (%s)",
            backend["name"], backend["ip"]
        )

    def get_healthy_backends(self):
        """Read backend health written by monitor.py."""
        try:
            with open(
                HEALTH_FILE, "r", encoding="utf-8"
            ) as health_file:
                health_data = json.load(health_file)

            timestamp = float(health_data["timestamp"])

            if time.time() - timestamp > HEALTH_FILE_MAX_AGE:
                self.logger.warning(
                    "Health file is stale; using all backends"
                )
                return BACKENDS

            statuses = health_data["servers"]

            healthy = [
                backend for backend in BACKENDS
                if statuses.get(backend["name"]) == "HEALTHY"
            ]

            self.logger.debug(
                "Healthy backends: %s",
                [backend["name"] for backend in healthy],
            )
            return healthy

        except (OSError, ValueError, KeyError, TypeError) as error:
            self.logger.warning(
                "Cannot read health file (%s); using all backends",
                error,
            )
            return BACKENDS

    def select_adaptive_backend(self):
        """Select a healthy backend using observed and assigned load."""
        healthy = self.get_healthy_backends()

        if not healthy:
            return None

        try:
            with open(HEALTH_FILE, "r", encoding="utf-8") as f:
                health_data = json.load(f)
            metrics = health_data.get("metrics", {})
        except (OSError, ValueError):
            metrics = {}

        # If metrics are unavailable, distribute requests among healthy
        # backends rather than repeatedly choosing the same backend.
        if not metrics or any(
            backend["name"] not in metrics for backend in healthy
        ):
            backend = healthy[self.next_backend % len(healthy)]
            self.next_backend = (
                BACKENDS.index(backend) + 1
            ) % len(BACKENDS)
            self.assignment_counts[backend["name"]] += 1
            self.logger.warning(
                "Metrics unavailable; using round-robin fallback: %s",
                backend["name"],
            )
            return backend

        rotation = self.next_backend % len(BACKENDS)
        order = {
            BACKENDS[(rotation + i) % len(BACKENDS)]["name"]: i
            for i in range(len(BACKENDS))
        }

        def load_score(backend):
            name = backend["name"]
            values = metrics.get(name, {})

            try:
                active = float(values["active_connections"])
                latency = float(values["average_processing_ms"])
                if active < 0 or latency < 0:
                    raise ValueError
            except (KeyError, TypeError, ValueError):
                active = float("inf")
                latency = float("inf")

            # When measured active loads tie, prefer the backend that
            # has received fewer assignments during this controller run.
            assigned = self.assignment_counts[name]

            return (
                active,
                assigned,
                latency,
                order[name],
            )

        backend = min(healthy, key=load_score)
        values = metrics.get(backend["name"], {})

        # Count this new assignment so rapid bursts don't all choose the
        # backend with a marginally lower historical latency.
        self.assignment_counts[backend["name"]] += 1
        self.next_backend = (
            BACKENDS.index(backend) + 1
        ) % len(BACKENDS)

        self.logger.info(
            "Adaptive selection: %s | active=%s | assigned=%s | avg_ms=%s",
            backend["name"],
            values.get("active_connections"),
            self.assignment_counts[backend["name"]],
            values.get("average_processing_ms"),
        )

        return backend

    def handle_new_connection(
        self, dp, msg, ip, tcp_header, client_mac
    ):
        client_ip = ip.src
        client_port = tcp_header.src_port
        key = (client_ip, client_port, VIP, SERVICE_PORT)

        self.client_macs[client_ip] = client_mac

        # Retransmitted SYNs retain their original backend assignment.
        if key in self.connections:
            backend = self.connections[key]
        else:
            backend = self.select_adaptive_backend()

            if backend is None:
                self.logger.warning(
                    "No healthy backends available; dropping SYN "
                    "from %s:%s",
                    client_ip,
                    client_port,
                )
                return

            self.connections[key] = backend

        if backend["mac"] is None:
            self.pending[key] = {
                "dp": dp,
                "in_port": msg.match["in_port"],
                "data": msg.data,
                "client_ip": client_ip,
                "client_mac": client_mac,
                "client_port": client_port,
                "backend": backend,
            }
            self.request_backend_mac(dp, msg, backend)
            return

        self.install_connection(
            dp,
            msg.match["in_port"],
            msg.data,
            client_ip,
            client_mac,
            client_port,
            backend,
        )

    def install_connection(
        self, dp, in_port, data, client_ip,
        client_mac, client_port, backend
    ):
        parser = dp.ofproto_parser

        forward_actions = [
            parser.OFPActionSetField(eth_dst=backend["mac"]),
            parser.OFPActionSetField(ipv4_dst=backend["ip"]),
            parser.OFPActionSetField(
                tcp_dst=backend["tcp_port"]
            ),
            parser.OFPActionOutput(backend["port"]),
        ]

        forward_match = parser.OFPMatch(
            in_port=in_port,
            eth_type=ether_types.ETH_TYPE_IP,
            ip_proto=6,
            ipv4_src=client_ip,
            ipv4_dst=VIP,
            tcp_src=client_port,
            tcp_dst=SERVICE_PORT,
        )

        self.add_flow(
            dp, 100, forward_match, forward_actions
        )

        reverse_actions = [
            parser.OFPActionSetField(eth_src=VIRTUAL_MAC),
            parser.OFPActionSetField(eth_dst=client_mac),
            parser.OFPActionSetField(ipv4_src=VIP),
            parser.OFPActionSetField(tcp_src=SERVICE_PORT),
            parser.OFPActionOutput(CLIENTS[client_ip]),
        ]

        reverse_match = parser.OFPMatch(
            in_port=backend["port"],
            eth_type=ether_types.ETH_TYPE_IP,
            ip_proto=6,
            ipv4_src=backend["ip"],
            ipv4_dst=client_ip,
            tcp_src=backend["tcp_port"],
            tcp_dst=client_port,
        )

        self.add_flow(
            dp, 100, reverse_match, reverse_actions
        )

        self.logger.info(
            "Assigned %s:%s to %s (%s)",
            client_ip,
            client_port,
            backend["name"],
            backend["mac"],
        )

        self.send_packet(
            dp,
            in_port,
            forward_actions,
            data,
        )
